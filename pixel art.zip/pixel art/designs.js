// creating variables 

const myColor = document.querySelector("#colorPicker");
const myTable = document.querySelector("#pixelCanvas");
const mySize = document.querySelector("#sizePicker");



function onAddWebsite(e) {
    e.preventDefault();
}



function logSubmit(event) {
    event.preventDefault();

}
formEl.add addEventListener('sumbit',logSubmit);

myColor.addEventListener('click', onAddwebsite); // to be able to change color


mySize.addEventListener('submit', function (e) {
    e.preventDefault();
    makeGrid()
}); 





function makeGrid() {
    myTable.innerHTML = "";
    let height2 = document.querySelector("#inputHeight").value;
    let width2 = document.querySelector("#inputWidth").value;
    
    for (let i = 0; i < height2; i++) {
        let rows = document.createElement('tr');
        for (let j = 0; j < width2; j++) {
            let columns = document.createElement("td");
            rows.appendChild(columns);
            columns.addEventListener("click", function (e) {
              e.target.style.backgroundColor = myColor.value;
            });
            myTable.appendChild(rows);
          }
        }


}